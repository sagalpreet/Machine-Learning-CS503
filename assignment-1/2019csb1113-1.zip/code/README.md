Assignment 1

The code for each of the 3 questions is present in form of a jupyter notebook. Running the entire jupyter notebook will plot the graphs and print required statements at appropriate places.

The observations have been written down and explained in markdown cells of the jupyter notebooks.
